#Keybase Gui
[![Build Status](https://travis-ci.org/jhbruhn/keybase-gui.svg?branch=master)](https://travis-ci.org/jhbruhn/keybase-gui)

Gui for GPG. Connected to keybase.io.

## What shall I do to start?
```
npm install
bower install
```

## But how do I build it?
```
grunt release
```
Now look into webkitbuilds/releases

## Nice, but how do I dev?
```
grunt dev
```
And in a new Shell-Session:
```
npm start
```
The webpage should reload itself automatically.
